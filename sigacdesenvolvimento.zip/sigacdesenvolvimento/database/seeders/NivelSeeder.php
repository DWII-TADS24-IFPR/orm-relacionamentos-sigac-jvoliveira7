<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Nivel;

class NivelSeeder extends Seeder
{
    public function run()
    {
        // Default levels for education system
        $niveis = [
            [
                'nome' => 'Técnico',
                'descricao' => 'Nível técnico profissionalizante',
                'ordem' => 1,
                'dificuldade' => 'intermediario',
                'ativo' => true
            ],
            [
                'nome' => 'Graduação',
                'descricao' => 'Nível de ensino superior',
                'ordem' => 2,
                'dificuldade' => 'avancado',
                'ativo' => true
            ],
            [
                'nome' => 'Pós-Graduação',
                'descricao' => 'Nível de especialização',
                'ordem' => 3,
                'dificuldade' => 'avancado',
                'ativo' => true
            ]
        ];

        foreach ($niveis as $nivel) {
            Nivel::create($nivel);
        }

        // Additional random levels if needed
        Nivel::factory()
            ->count(2)
            ->create();
    }
}