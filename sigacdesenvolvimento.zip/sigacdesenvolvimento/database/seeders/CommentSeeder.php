<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Aluno; // Importando o modelo Aluno
use Faker\Factory as Faker;

class CommentSeeder extends Seeder
{
    public function run(): void
    {
        $faker = Faker::create(); 

   
        foreach (range(1, 10) as $index) {
            DB::table('comments')->insert([
                'aluno_id' => Aluno::inRandomOrder()->first()->id, 
                'comentario' => $faker->sentence, 
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        echo "10 Comentários gerados com sucesso!";
    }
}
