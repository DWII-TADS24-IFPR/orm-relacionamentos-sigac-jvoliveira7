<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Turma;
use App\Models\Curso;
use App\Models\Professor;
use App\Models\Aluno;
use Carbon\Carbon;

class TurmaSeeder extends Seeder
{
    public function run()
    {
        // Cria 10 turmas
        Turma::factory()
            ->count(10)
            ->create()
            ->each(function ($turma) {
                // Associa um curso existente (ou cria um se não existir)
                $curso = Curso::inRandomOrder()->first() ?? Curso::factory()->create();
                $turma->curso()->associate($curso);
                
                // Associa um professor existente (ou cria um se não existir)
                $professor = Professor::inRandomOrder()->first() ?? Professor::factory()->create();
                $turma->professor()->associate($professor);
                
                $turma->save();
                
                // Matricula entre 5 e 20 alunos aleatórios na turma
                $alunos = Aluno::inRandomOrder()
                    ->limit(rand(5, 20))
                    ->get();
                
                $turma->alunos()->attach($alunos, [
                    'data_matricula' => Carbon::now()->subDays(rand(1, 30)),
                    'status' => ['matriculado', 'ativo', 'trancado'][rand(0, 2)],
                    'nota_final' => rand(0, 10) > 3 ? rand(50, 100) / 10 : null
                ]);
            });
    }
}