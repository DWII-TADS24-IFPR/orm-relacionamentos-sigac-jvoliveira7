<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Eixo;

class EixoSeeder extends Seeder
{
    public function run()
    {
      
        Eixo::factory()
            ->count(5)
            ->create();
            
        // Create specific eixos
        Eixo::create([
            'nome' => 'Tecnologia da Informação',
            'descricao' => 'Eixo tecnológico relacionado a computação e TI',
            'ativo' => true
        ]);
        
        Eixo::create([
            'nome' => 'Gestão e Negócios',
            'descricao' => 'Eixo tecnológico de administração e negócios',
            'ativo' => true
        ]);
    }
}