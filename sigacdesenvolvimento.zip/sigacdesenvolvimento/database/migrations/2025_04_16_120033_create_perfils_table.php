<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('perfis', function (Blueprint $table) {
            $table->id();
            $table->text('bio'); 
            $table->string('foto')->nullable();
            $table->string('website')->nullable();
            $table->foreignId('pessoa_id')
                  ->constrained('pessoas')
                  ->onDelete('cascade')
                  ->onUpdate('cascade'); 
            $table->timestamps();
            $table->softDeletes(); 
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('perfis');
    }
};