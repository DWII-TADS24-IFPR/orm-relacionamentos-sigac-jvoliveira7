<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cursos', function (Blueprint $table) {
            $table->id();
            $table->string('nome', 100);
            $table->string('sigla', 10);
            $table->integer('total_horas');
            $table->unsignedBigInteger('nivel_id');
            $table->unsignedBigInteger('eixo_id');
            $table->timestamps();
            $table->softDeletes();
            
 
            $table->foreign('nivel_id')
                  ->references('id')
                  ->on('niveis')
                  ->onDelete('restrict')
                  ->onUpdate('cascade');
                  
            $table->foreign('eixo_id')
                  ->references('id')
                  ->on('eixos')
                  ->onDelete('restrict')
                  ->onUpdate('cascade');
            
   
            $table->index('nome');
            $table->index('sigla');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cursos', function (Blueprint $table) {
            // Drop foreign keys first to avoid errors
            $table->dropForeign(['nivel_id']);
            $table->dropForeign(['eixo_id']);
        });
        
        Schema::dropIfExists('cursos');
    }
};