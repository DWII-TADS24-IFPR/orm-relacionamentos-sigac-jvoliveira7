<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('turmas', function (Blueprint $table) {
            $table->id();
            $table->string('codigo', 20)->unique();
            $table->string('nome', 100);
            $table->year('ano_letivo');
            $table->tinyInteger('semestre');
            $table->date('data_inicio');
            $table->date('data_fim');
            $table->json('horario')->nullable(); // Dias e horários das aulas
            $table->string('status', 20)->default('planejada');
            
            // Foreign keys
            $table->foreignId('curso_id')->constrained()->onDelete('restrict');
            $table->foreignId('professor_id')->constrained('professores')->onDelete('restrict');
            $table->foreignId('sala_id')->constrained('salas')->onDelete('restrict');
            
            $table->timestamps();
            $table->softDeletes();
            
            // Indexes
            $table->index('codigo');
            $table->index(['ano_letivo', 'semestre']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('turmas');
    }
};   