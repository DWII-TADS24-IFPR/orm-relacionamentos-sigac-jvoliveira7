<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('niveis', function (Blueprint $table) {
            $table->id();
            $table->string('nome', 100);
            $table->text('descricao')->nullable();
            $table->integer('ordem')->unique();
            $table->string('dificuldade', 20)->default('intermediario');
            $table->boolean('ativo')->default(true);
            $table->timestamps();
            $table->softDeletes();
            
            $table->index('nome');
            $table->index('ordem');
            $table->index('ativo');
        });
    }

    public function down()
    {
        Schema::dropIfExists('niveis');
    }
};