<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('aluno_role', function (Blueprint $table) {
           
            $table->foreignId('aluno_id')
                  ->constrained() 
                  ->onDelete('cascade')
                  ->onUpdate('cascade');
                  
            $table->foreignId('role_id')
                  ->constrained() 
                  ->onDelete('cascade')
                  ->onUpdate('cascade');

            
            $table->primary(['aluno_id', 'role_id']);
            
            
            $table->dateTime('assigned_at')->useCurrent();
            $table->dateTime('expires_at')->nullable();
            
            $table->timestamps();
            
            $table->index('expires_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('aluno_role', function (Blueprint $table) {
            // Properly drop foreign keys first (important for SQLite)
            $table->dropForeign(['aluno_id']);
            $table->dropForeign(['role_id']);
        });
        
        Schema::dropIfExists('aluno_role');
    }
};