@extends()

@section('content')

<h1>Index Niveis</h1>

<table class="table table-white">
    <thead>
        
    </thead>

</table>