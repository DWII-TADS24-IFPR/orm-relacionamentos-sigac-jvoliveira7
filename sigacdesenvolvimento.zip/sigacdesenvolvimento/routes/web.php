<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\PessoaController;
use App\Http\Controllers\EixoController;
use App\Http\Controllers\NivelController;




// ROTAS DE PESSOAS
Route::get('/pessoas', [PessoaController::class, 'index'])->name('pessoas.index');
Route::get('/pessoas/create', [PessoaController::class, 'create']);
Route::post('/pessoas', [PessoaController::class, 'store'])->name('pessoas.store');

// ROTAS DE EIXO (RESOURCE)
Route::resource('/eixo', EixoController::class);

// ROTAS SIMPLES
Route::get('/simples', function () {
    return "<h1>Rota Simples</h1>";
});

// PARÂMETROS
Route::get('/parametro/{a}', function ($a) {
    return "<h1>Parâmetro recebido: $a</h1>";
});

Route::get('/parametros/{a}/{b}/{c}', function ($a, $b, $c) {
    return "<h1>Parâmetros recebidos: $a / $b / $c</h1>";
});

Route::get('/opcionais/{a}/{b}/{c?}', function ($a, $b, $c = 0) {
    return "<h1>Opcionais: $a / $b / $c</h1>";
});

// REGRAS DE VALIDAÇÃO DE PARÂMETROS
Route::get('/regras/{a}/{b}', function ($a, $b) {
    return "<h1>Parâmetros com regras: $a / $b</h1>";
})->where('a', '[0-9]+')->where('b', '[A-Za-z]+');

// AGRUPAMENTO
Route::prefix('/agrupamento')->group(function () {
    Route::get('/', function () {
        return "<h1>Agrupamento: rota raiz</h1>";
    })->name('agrupamento');

    Route::get('/um', function () {
        return "<h1>Agrupamento: rota um</h1>";
    })->name('agrupamento.um');

    Route::get('/dois', function () {
        return "<h1>Agrupamento: rota dois</h1>";
    })->name('agrupamento.dois');
});

// REDIRECIONAMENTO
Route::get('/redirecionar', function () {
    return redirect()->route('agrupamento');
});

// POST
Route::post('/add', function (Request $request) {
    return "<h1>Requisição POST</h1>";
});

Route::resource('/niveis', NivelController::class);