<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\NivelRepository;
use App\Models\Nivel;

class NivelController extends Controller
{
    protected $repository;

    public function __construct()
    {
        $this->repository = new NivelRepository();
    }

    public function index()
    {
        $niveis = $this->repository->selectAll();
        return view('niveis.index')->with(['niveis'=>$niveis]);
    }

    public function create()
    {
        return view('niveis.create');
    }

    public function store(Request $request)
    {
        $nivel = new Nivel();
        $nivel->nome = $request->nome;

        $this->repository->save($nivel);

        return redirect()->route('niveis.index');
    }

    public function edit($id)
    {
        $nivel = $this->repository->findById($id);

        if (!$nivel) {
            return redirect()->route('niveis.index')->withErrors('Nível não encontrado.');
        }

        return view('niveis.edit', compact('nivel'));
    }

    public function update(Request $request, $id)
    {
        $nivel = $this->repository->findById($id);

        if ($nivel) {
            $nivel->nome = $request->nome;
            $this->repository->save($nivel);

            return redirect()->route('niveis.index');
        }

        return redirect()->route('niveis.index')->withErrors('Erro ao atualizar.');
    }

    public function destroy($id)
    {
        if ($this->repository->delete($id)) {
            return redirect()->route('niveis.index');
        }

        return redirect()->route('niveis.index')->withErrors('Erro ao excluir.');
    }
}
