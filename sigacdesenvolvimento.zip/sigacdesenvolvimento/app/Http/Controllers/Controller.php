<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    /**
     * Página inicial genérica do sistema
     */
    public function index()
    {
        return view('inicio');
    }

    /**
     * Página sobre o sistema
     */
    public function sobre()
    {
        return view('sobre', [
            'app' => 'Sistema Acadêmico',
            'versao' => '1.0',
            'autor' => 'Seu Nome'
        ]);
    }

    /**
     * Página de ajuda
     */
    public function ajuda()
    {
        return view('ajuda');
    }
}
