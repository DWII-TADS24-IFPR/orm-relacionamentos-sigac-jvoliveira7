<?php

namespace App\Repositories;

use App\Models\Nivel;

class NivelRepository
{
    public function selectAll()
    {
        return Nivel::all();
    }

    public function findById($id)
    {
        return Nivel::find($id);
    }

    public function save(Nivel $nivel)
    {
        $nivel->save();
    }

    public function delete($id)
    {
        $nivel = Nivel::find($id);
        if ($nivel) {
            $nivel->delete();
            return true;
        }
        return false;
    }
}
