<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Aluno;

class Comprovante extends Model
{
    use SoftDeletes;

    protected $table = 'comprovantes';

    protected $fillable = [
        'aluno_id',
        'tipo',
        'arquivo', 
    ];

    protected $dates = ['deleted_at'];

    /**
     * Relacionamento: um comprovante pertence a um aluno
     */
    public function aluno()
    {
        return $this->belongsTo(Aluno::class);
    }
}
