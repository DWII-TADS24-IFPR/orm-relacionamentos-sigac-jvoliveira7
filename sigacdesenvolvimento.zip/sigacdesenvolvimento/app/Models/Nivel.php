<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Nivel extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'niveis';
    
    protected $fillable = [
        'nome',
        'descricao',
        'ordem',
        'dificuldade',
        'ativo'
    ];

    protected $casts = [
        'ordem' => 'integer',
        'ativo' => 'boolean',
        'created_at' => 'datetime:d/m/Y H:i',
        'updated_at' => 'datetime:d/m/Y H:i'
    ];

    protected $dates = [
        'deleted_at'
    ];

    /**
     * Relationship with cursos
     */
    public function cursos(): HasMany
    {
        return $this->hasMany(Curso::class);
    }

    /**
     * Scope for active niveis
     */
    public function scopeAtivo($query)
    {
        return $query->where('ativo', true);
    }

    /**
     * Get the display name attribute
     */
    public function getNomeCompletoAttribute(): string
    {
        return "Nível {$this->ordem} - {$this->nome}";
    }
}