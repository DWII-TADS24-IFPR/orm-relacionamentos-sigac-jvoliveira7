<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Role;
use App\Models\Curso;

class Aluno extends Model
{
    use SoftDeletes;

    protected $table = 'alunos';
    protected $fillable = [
        'nome',
        'cpf',
        'email',
        'telefone', 
    ];
    
    protected $dates = ['deleted_at'];

    public function roles()
    {
        return $this->belongsToMany(Role::class)->withTimestamps();
    }

    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }
    
    public function cursos()
    {
        return $this->belongsToMany(Curso::class)->withTimestamps();
    }
}