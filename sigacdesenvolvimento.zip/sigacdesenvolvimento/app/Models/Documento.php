<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Aluno;

class Documento extends Model
{
    use SoftDeletes;

    protected $table = 'documentos';

    protected $fillable = [
        'aluno_id',
        'nome',
        'tipo',
        'caminho', 
    ];

    protected $dates = ['deleted_at'];

    /**
     * Um documento pertence a um aluno
     */
    public function aluno()
    {
        return $this->belongsTo(Aluno::class);
    }
}
