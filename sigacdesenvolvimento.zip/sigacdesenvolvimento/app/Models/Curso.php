<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Curso extends Model
{
    use SoftDeletes;

    protected $table = 'cursos';
    protected $fillable = [
        'nome',
        'descricao',
        'carga_horaria',
    ];
    
    protected $dates = ['deleted_at'];

    public function alunos()
    {
        return $this->belongsToMany(Aluno::class)->withTimestamps();
    }
}