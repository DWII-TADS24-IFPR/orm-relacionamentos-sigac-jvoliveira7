<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Turma extends Model
{
    use SoftDeletes;

    protected $table = 'turmas';
    
    protected $fillable = [
        'codigo',
        'nome',
        'ano_letivo',
        'semestre',
        'data_inicio',
        'data_fim',
        'curso_id',
        'professor_id',
        'sala_id',
        'horario',
        'status'
    ];

    protected $casts = [
        'data_inicio' => 'date',
        'data_fim' => 'date',
        'horario' => 'array' 
    ];

    protected $dates = ['deleted_at'];

    /**
     * Relacionamento com Curso
     */
    public function curso(): BelongsTo
    {
        return $this->belongsTo(Curso::class);
    }

    /**
     * Relacionamento com Professor
     */
    public function professor(): BelongsTo
    {
        return $this->belongsTo(Professor::class);
    }

    /**
     * Relacionamento com Sala
     */
    public function sala(): BelongsTo
    {
        return $this->belongsTo(Sala::class);
    }

    /**
     * Alunos matriculados na turma
     */
    public function alunos(): BelongsToMany
    {
        return $this->belongsToMany(Aluno::class, 'aluno_turma')
                   ->withPivot(['data_matricula', 'status', 'nota_final'])
                   ->withTimestamps();
    }

    /**
     * Aulas da turma
     */
    public function aulas(): HasMany
    {
        return $this->hasMany(Aula::class);
    }

    /**
     * Scope para turmas ativas
     */
    public function scopeAtivas($query)
    {
        return $query->where('status', 'ativo');
    }

    /**
     * Scope para turmas do ano atual
     */
    public function scopeDoAnoAtual($query)
    {
        return $query->where('ano_letivo', date('Y'));
    }
}