<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Perfil;

class Pessoa extends Model
{
    use SoftDeletes;

    protected $table = 'pessoas';
    protected $fillable = [
        'nome', 
        'idade'
    ];
    
    protected $dates = ['deleted_at'];

    public function perfil(): HasOne
    {
        return $this->hasOne(Perfil::class);
    }
}