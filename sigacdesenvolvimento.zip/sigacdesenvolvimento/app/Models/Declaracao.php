<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Aluno;

class Declaracao extends Model
{
    use SoftDeletes;

    protected $table = 'declaracoes';

    protected $fillable = [
        'aluno_id',
        'curso',
        'data_emissao',
    ];

    protected $dates = ['deleted_at', 'data_emissao'];

    // Relacionamento: cada declaração pertence a um aluno
    public function aluno()
    {
        return $this->belongsTo(Aluno::class);
    }
}
